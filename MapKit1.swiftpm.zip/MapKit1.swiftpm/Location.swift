//
//  File.swift
//  MapKit1
//
//  Created by Fiona Chiu on 2022/10/26.
//

import Foundation

struct Location: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    let latitude: Double
    let longitude: Double
}
